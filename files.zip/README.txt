# Student Performance Analyzer — Setup Guide

## Files in this project

- index.html   → Main dashboard page
- style.css    → All styling
- app.js       → Frontend logic (charts, tables, API calls)
- server.py    → Flask backend (ML + API)

---

## Step 1 — Install Python packages

Run this once in your terminal:

    pip install flask flask-cors pandas numpy scikit-learn

---

## Step 2 — Start the Flask server

    python server.py

You should see: Running on http://127.0.0.1:5000

---

## Step 3 — Open the frontend

Open index.html in your browser (double-click it, or use VS Code Live Server).

---

## Step 4 — Use the dashboard

1. Click "Drop your CSV file here" and select your student CSV
2. Click Analyze
3. Wait a few seconds for the ML to run
4. View the dashboard: summary cards, charts, suspicious students, model metrics

---

## CSV Format Required

Your CSV must have these columns (exact names):

- Attendance (%)
- Internal Test 1 (out of 40)
- Internal Test 2 (out of 40)
- Assignment Score (out of 10)
- Daily Study Hours
- Final Exam Marks (out of 100)
- Student_ID  (optional but recommended)

---

## Troubleshooting

- "Error: Failed to fetch" → Make sure server.py is running first
- "Server error: 500" → Check your CSV column names match the format above
- Chart not showing → Make sure you have internet access (Chart.js loads from CDN)
